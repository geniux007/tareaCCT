/*
* Autor: Christian Castro
*/

$( "#pb1" ).on( "mouseover", function(){
	var numPg4 = Math.floor(Math.random() * 101);
  $( this ).css( "width", numPg4+"%" );
  $( this ).text( numPg4+"% - Cuzco" );
  
});
$( "#pb2" ).on( "mouseover", function(){
	var numPg4 = Math.floor(Math.random() * 101);
  $( this ).css( "width", numPg4+"%" );
  $( this ).text( numPg4+"% - AYACUCHO" );
  
});
$( "#pb3" ).on( "mouseover", function(){
	var numPg4 = Math.floor(Math.random() * 101);
  $( this ).css( "width", numPg4+"%" );
  $( this ).text( numPg4+"% - PUNO" );
  
});
$( "#pb4" ).on( "mouseover", function(){
	var numPg4 = Math.floor(Math.random() * 101);
  $( this ).css( "width", numPg4+"%" );
  $( this ).text( numPg4+"% - LORETO" );
  
});

$(".head-acordion").click(function(){
	$(this).toggleClass("visto")
	//$(".contenido").show();
	/*$(".contenido").hide();
	$(this).parent().find(".contenido").show();*/
	//$(".contenido").hide();
	
	$(this).parent().find(".contenido").slideToggle();
	//$(this).parent().find(".contenido").toggle();
	//$(this).parent().find(".contenido").fadeIn();

})